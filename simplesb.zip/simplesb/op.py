from linepy import *
from liff.ttypes import *
from linepy import*
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from tmp.MySplit import *
from datetime import datetime
from datetime import timedelta
from gtts import gTTS
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from io import StringIO
import subprocess
import youtube_dl, math
import humanize
import traceback
import time
import random
import sys
import pafy
import os
import json
import null
import codecs
import html5lib
import shutil
import glob
import re
import base64
import string
import requests
import ast
import pytz
import platform
import wikipedia
import importlib
import atexit
import asyncio
import livejson
loop = asyncio.get_event_loop()
kalera = LINE("@gmail.com","password")
print("login success")
kaleraMID = kalera.profile.mid
kaleraProfile = kalera.profile
kalera_poll = OEPoll(kalera)
waitOpen = codecs.open("wait.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
#==================
cctv = {
	"cyduk":{},
	"point":{},
	"MENTION":{},
	"sidermem":{}
}

read = {
	"readPoint": {},
	"readMember": {},
	"readTime": {},
	"ROM": {}
}
#==========
with open("temp.json", "r", encoding="utf_8_sig") as f:
	set = json.loads(f.read())
	set.update(settings)
	settings = set
with open("wait.json", "r", encoding="utf_8_sig") as f:
	waits = json.loads(f.read())
	waits.update(wait)
	wait = waits
def speed_fetch():
	start = time.time()
	get = kalera.getProfile()
	taken = time.time() - start
	took = time.time() - start
	return "Speed Fetch♪\n- Took : %.3fms♪\n- Taken : %.6fms♪" % (took,taken)
def sendMessageCustom(to, text, icon , name):
	annda = {'MSG_SENDER_ICON': icon,
		'MSG_SENDER_NAME':  name,
	}
	kalera.sendMessage(to, text, contentMetadata=annda)
def allow_liff():
	url = 'https://access.line.me/dialog/api/permissions'
	data = {
	    'on': [
	        'P',
	        'CM'
	    ],
	    'off': []
	}
	headers = {
	    'X-Line-Access': kalera.authToken,
	    'X-Line-Application': kalera.server.APP_NAME,
	    'X-Line-ChannelId': '1653391722',
	    'Content-Type': 'application/json'
	}
	requests.post(url, json=data, headers=headers)
def sendTemplate(group, data):
	allow_liff()
	xyz = LiffChatContext(group)
	xyzz = LiffContext(chat=xyz)
	view = LiffViewRequest('1653391722-QN5aXrrz', xyzz)
	token = kalera.liff.issueLiffView(view)
	url = 'https://api.line.me/message/v3/share'
	headers = {
	    'Content-Type': 'application/json',
	    'Authorization': 'Bearer %s' % token.accessToken
	}
	data = {"messages":[data]}
	requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(to, data):
	allow_liff()
	xyz = LiffChatContext(to)
	xyzz = LiffContext(chat=xyz)
	view = LiffViewRequest('1653391722-QN5aXrrz', xyzz)
	token = kalera.liff.issueLiffView(view)
	url = 'https://api.line.me/message/v3/share'
	headers = {
	    'Content-Type': 'application/json',
	    'Authorization': 'Bearer %s' % token.accessToken
	}
	data = {"messages":[data]}
	requests.post(url, headers=headers, data=json.dumps(data))
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "Kalera Team",
            "iconUrl": "https://i.ibb.co/vc7Ntfz/1610490636382.jpg",
            "linkUrl": "line://app/1571191887-d6rJnOxJ/?type=text&text=Gua%20Tolol%20Banget"
        }
    }
    sendTemplate(to, data)
def siderMembers(to, mid):
	try:
		arrData = ""
		textx = "Kau tercyduk ".format(str(mid))
		arr = []
		no = 1
		num = 2
		for i in mid:
			mention = "@PenaxNoi\n"
			slen = str(len(textx))
			elen = str(len(textx) + len(mention) - 1)
			arrData = {'S':slen, 'E':elen, 'M':i}
			arr.append(arrData)
			textx += mention
			if no < len(mid):
				no += 1
				textx += "%i. " % (num)
				num=(num+1)
			else:
				try:
					no = "\n {} ".format(str(kalera.getGroup(to).name))
				except:
					no = "\n Success "
		kalera.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
	except Exception as error:
		kalera.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def command(text):
	noi = text.lower()
	if settings["setKey"] == True:
		if noi.startswith(settings["keyCommand"]):
			cmd = noi.replace(settings["keyCommand"],"")
		else:
			cmd = "Undefined Command"
	else:
		cmd = text.lower()
	return cmd
def restartBot():
	python = sys.executable
	os.execl(python,python,*sys.argv)
def changeVideoAndPictureProfile(pict, vids):
	try:
		files = {'file': open(vids, 'rb')}
		obs_params = kalera.genOBSParams({'oid': kaleraMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
		data = {'params': obs_params}
		r_vp = kalera.server.postContent('{}/talk/vp/upload.nhn'.format(str(kalera.server.kalera_OBS_DOMAIN)), data=data, files=files)
		if r_vp.status_code != 201:
			return "Failed..."
		kalera.updateProfilePicture(pict, 'vp')
		return "Success..."
	except Exception as e:
		raise Exception("Error change video and picture profile {}".format(str(e)))
		os.remove("ExcellentTeamBots.mp4")
selp = """「KaleraTeam」
⌬ Self Commands :
     ⌬ MyPict
     ⌬ MyMid
     ⌬ MyBio
     ⌬ MyName
     ⌬ GroupList
     ⌬ Bcast 「Text」
     ⌬ Clearchat
By : Kalera Team
"""
medias = """「KaleraTeam」
⌬ Media Commands :
     ⌬ Corona
     ⌬ Gempa
     ⌬ Music 「Tittle」
     ⌬ Hentai
     ⌬ Kbbi
     ⌬ Tribun News
	  ⌬ Ssweb 「URL」
	  ⌬ Gmaps 「Area」
	  ⌬ Jadwal Sholat
     ⌬ Quotes
⌬ By : Kalera Team
"""
steals = """「 KaleraTeam」
⌬ Media Commands :
    ⌬ GetName @Tag
    ⌬ GetBio @Tag
    ⌬ GetPicture @Tag
    ⌬ GetCover @Tag
    ⌬ GetContact @Tag
    ⌬ Chat @Tag 「Text」
    ⌬ Kick @Tag
⌬ By : Kalera Team
"""
#==================
async def ibal_kalera(op):
	try:
		if op.type == 0:
			return
		if op.type == 5:
			pesan = ["Haii","Thanks For Add Me","Hai!!"] #You Can Custome It
			rndm = random.choice(pesan)
			kalera.sendMessage(op.param1, rndm)
		if op.type == 25:
			msg = op.message
			text = msg.text
			reply = msg.id
			receiver = msg.to
			sender = msg._from
			to = msg.to
			isValid = True
			if isValid != False:
				if msg.toType == 0 and sender != ibalMID: to = sender
				else: to = receiver
				if msg.contentType == 0:
					if text is None:pass
					else:
					   spenah = msg.text.lower()
					for penah in spenah.split(" & "):
						if penah == "hi":
							kalera.sendReplyMessage(msg.id,to, "Hi Too!")
						elif penah == "help":
							dataa = {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/XXYV038/images-36.jpg","size": "full","aspectMode": "cover","aspectRatio": "1:1","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "⌬ Help Commands ⌬","weight": "bold","align": "center","wrap": True,"adjustMode": "shrink-to-fit","color": "#ffffff"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Media","color": "#ffffff"}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "50px","offsetStart": "20px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Profile","color": "#ffffff","wrap": True}],"offsetTop": "90px","position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "90px","offsetStart": "20px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Steal","size": "md","wrap": True,"color": "#ffffff"}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "50px","offsetStart": "80px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Sider","size": "md","color": "#ffffff","wrap": True}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "90px","offsetStart": "80px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Speed","size": "md","color": "#ffffff","wrap": True}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "50px","offsetStart": "130px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Byeme","size": "md","color": "#ffffff","wrap": True}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "90px","offsetStart": "130px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Logout","size": "md","color": "#ffffff","wrap": True}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "50px","offsetStart": "190px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Restbot","size": "md","color": "#ffffff","wrap": True}],"position": "absolute","borderWidth": "light","borderColor": "#ffffff","cornerRadius": "sm","offsetTop": "90px","offsetStart": "190px"}],"position": "absolute","offsetBottom": "0px","offsetStart": "0px","offsetEnd": "0px","paddingAll": "20px","offsetTop": "130px"}],"paddingAll": "0px"}}
							data = {"type": "flex","altText": "Help","contents": {"type": "carousel","contents": [dataa]}}
							sendTemplate(to,data)
						elif penah == "media":
							sendFooter(to, medias)
						elif penah == "about":
							ac = subprocess.getoutput('lsb_release -a')
							am = subprocess.getoutput('cat /proc/meminfo')
							ax = subprocess.getoutput('lscpu')
							core = subprocess.getoutput('grep -c ^processor /proc/cpuinfo ')
							for line in ac.splitlines():
								if 'Description:' in line:
									os = line.split('Description:')[1].replace(' ','')
							for line in ax.splitlines():
								if 'Architecture:' in line:
									architecture =  line.split('Architecture:')[1].replace(' ','')
							for line in am.splitlines():
								if 'MemTotal:' in line:
									mem = line.split('MemTotal:')[1].replace(' ','')
								if 'MemFree:' in line:
									fr = line.split('MemFree:')[1].replace(' ','')
							res = "「 About Bots 」\n"
							res += "\t\t\t⌬ Type : Selfbot\n"
							res += "\t\t\t⌬ Version : 1.0\n"
							res += "\t\t\t⌬ Moderator : Spenah♪\n"
							res += "\t\t\t⌬ Creator : Spenah♪\n\n"
							res += "「 About System 」\n"
							res += f"\t\t\t⌬ vCore : {core}\n"
							res += f"\t\t\t⌬ OS System : {os}\n"
							res += f"\t\t\t⌬ Language : Python\n"
							res += f"\t\t\t⌬ Version : 3.8\n"
							res += f"\t\t\t⌬ Total Memory : {mem}\n"
							res += f"\t\t\t⌬ Free Memory : {fr}\n"
							res += f"\t\t\t⌬ Architecture : {architecture}\n\n"
							res += "「 Spesial Thanks 」\n"
							res += "\t\t\t⌬ B O B B Y™\n\t\t\t⌬ Ben\n\t\t\t⌬ Ibal™♪\n\t\t\t⌬ Bee\n\t\t\t⌬ Igoyyy™♪\n\n"
							res += "「 Supported 」\n"
							res += "\t\t\t⌬ Noi-Bots™♪\n\t\t\t⌬ We Bare Bears™\n\t\t\t⌬ Project Beta\n\t\t\t⌬ NoelV2™\n\t\t\t⌬ MPCORS™\n\t\t\t⌬ ExcellentTeamBots♪\n\t\t\t⌬ BoneToReborn\n\t\t\t⌬ P.K BOTS\n\t\t\t⌬ RED〘赤〙\nAnd All Of My Friends ♪\n\nCopyright ©2020\nRegards : Kalera Team♪"
							sendFooter(to, str(res))
						elif penah == "profile":
							sendFooter(to, selp)
						elif penah == "steal":
							sendFooter(to, steals)
						elif penah == "byeme":
							sendFooter(to, "See You♪")
						elif penah == "speed":
							sendFooter(to, speed_fetch())
						elif penah == "grouplist":
								gid = kalera.getGroupIdsJoined()
								sd = kalera.getGroups(gid)
								ret = "「 Group List 」\n"
								no = 0
								total = len(gid)
								cd = "\n\nTotal groups : {} \n────────────────────\n⌬ Bcast\n".format(total)
								for G in sd:
									member = len(G.members)
									no += 1
									ret += "\n{}. {} ({})".format(no, G.name[0:50], member)
								ret += cd
								k = len(ret)//10000
								for aa in range(k+1):
									kalera.generateReplyMessage(msg.id)
									sendFooter(to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
						elif penah == "restbot":
							kalera.sendReplyMessage(msg.id,to, "Restarting♪")
							time.sleep(2)
							kalera.sendReplyMessage(msg.id,to, "Done")
							restartBot()
						elif penah == "mypict":
							path = kalera.getContact(sender).pictureStatus
							kalera.sendImageWithURL(to,"https://obs.line-scdn.net/{}".format(str(path)))
							sendFooter(to,"https://obs.line-scdn.net/{}".format(str(path)))
						elif kalera == "clearchat":
							kalera.removeAllMessages(op.param2)
							time.sleep(0.2)
							kalera.sendReplyMessage(msg.id,to, " Allchat deleted ")
						elif penah == "myname":
							sendFooter(to,"⌬ Name :\n"+str(kalera.getContact(sender).displayName))
						elif penah == "mymid":
							sendFooter(to, '⌬ Your Mid\n' + str(kalera.profile.mid))
						elif penah == "mybio":
							sendFooter(to,"⌬ Bio :\n"+str(kalera.getContact(sender).statusMessage))
						elif penah == 'logout':
							kalera.sendMessage(to,"Success Logout")
							time.sleep(3)
							sys.exit('Logout')
						elif penah == 'sider on':
							try:
								kalera.sendReplyMessage(msg.id,to, "⌬ Check Sider Set To Enable")
								del cctv['point'][to]
								del cctv['sidermem'][to]
								del cctv['cyduk'][to]
							except:
								pass
							cctv['point'][to] = msg.id
							cctv['sidermem'][to] = ""
							cctv['cyduk'][to]=True
						elif penah == 'sider off':
							if to in cctv['point']:
								cctv['cyduk'][to]=False
								kalera.sendReplyMessage(msg.id,to, "⌬ Check Sider Set To Disable")
							else:
								kalera.sendReplyMessage(msg.id,to, "⌬ Check Sider Has Been Disable")
						elif penah == "gempa":
							try:
								r = json.loads(requests.get("https://mnazria.herokuapp.com/api/bmkg-gempa").text)
								kalera.sendImageWithURL(to, r["result"])
							except Exception as e:
								kalera.sendReplyMessage(msg.id, to, str(e))
						elif penah.startswith("music "):
							try:
								sep = penah.split(" ")
								queryy = penah.replace(sep[0] + " ","")
								r = json.loads(requests.get(f"https://mnazria.herokuapp.com/api/jooxnich?search={queryy}").text)
								#devi.sendReplyImageWithURL(msg.id, to, r["result"]["album_url"])
								kalera.sendReplyMessage(msg.id, to, r["lirik"])
								kalera.sendAudioWithURL(to, r["result"]["mp3Url"])
							except Exception as e:
								kalera.sendReplyMessage(msg.id, to, str(e))
						elif penah.startswith("kbbi "):
							try:
								sep = penah.split(" ")
								hehe = penah.replace(sep[0] + " ","")
								r = requests.get(f"https://mnazria.herokuapp.com/api/kbbi?search={hehe}")
								data = json.loads(r.text)
								ret = f"KBBI From : {hehe}\n"
								ret += "\n• "+str(data["result"][0])
								kalera.sendReplyMessage(msg.id, to, str(ret))
							except Exception as e:
								kalera.sendReplyMessage(msg.id, to, str(e))
						elif penah == "corona":
							try:
								r = requests.get("https://ibalapi.herokuapp.com/api/kawalcorona")
								data = json.loads(r.text)
								ret = "Info Corona Indonesia\n"
								ret += "\n• City : "+str(data["result"]["city"])
								ret += "\n• Death : "+str(data["result"]["death"])
								ret += "\n• Healed : "+str(data["result"]["heal"])
								ret += "\n• Case : "+str(data["result"]["opname"])
								ret += "\n• Positive : "+str(data["result"]["positive"])
								kalera.sendReplyMessage(msg.id, to, str(ret))
							except Exception as e:
								ibal.sendReplyMessage(msg.id, to, str(e))
						elif penah == "hentai":
							try:
								r = json.loads(requests.get("https://mnazria.herokuapp.com/api/picanime?list=lewd").text)
								kalera.sendImageWithURL(to, r["gambar"])
							except Exception as e:
								kalera.sendReplyMessage(msg.id, to, str(e))
						elif penah.startswith("ssweb "):
							sep = text.split(" ")
							query = text.replace(sep[0] + " ","")
							r = json.loads(requests.get(f'https://mnazria.herokuapp.com/api/screenshotweb?url={query}').text)
							kalera.sendImageWithURL(to, r["gambar"])
						elif penah == "tribun news":
							 r = requests.get("https://ibalapi.herokuapp.com/api/tribunnews")
							 data = json.loads(r.text)
							 ret = "「TribunNews」\n"
							 ret += "\n• Title : "+str(data["result"][0]["title"])
							 ret += "\n• Url : "+str(data["result"][0]["url"])
							 ret += "\n• Title : "+str(data["result"][1]["title"])
							 ret += "\n• Url : "+str(data["result"][1]["url"])
							 ret += "\n• Title : "+str(data["result"][2]["title"])
							 ret += "\n• Url : "+str(data["result"][2]["url"])
							 kalera.sendReplyMessage(msg.id, to, str(ret))
						elif penah.startswith("gmaps "):
							sep = text.split(" ")
							query = text.replace(sep[0] + " ","")
							r = json.loads(requests.get(f'https://mnazria.herokuapp.com/api/maps?search={query}').text)
							kalera.sendImageWithURL(to, r["gambar"])
						elif penah == "jadwal sholat":
							r = json.loads(requests.get(f'https://ibalapi.herokuapp.com/api/jadwalsholat?daerah=jakarta barat').text)
							ret = "「Jadwal sholat」\n"
							ret += "\n• Dzuhur : " + str(r["result"]["dzuhur"])
							ret += "\n• Subuh : " + str(r["result"]["subuh"])
							ret += "\n• Maghrib : " + str(r["result"]["maghrib"])
							ret += "\n• Ashar : " + str(r["result"]["ashar"])
							ret += "\n• Isya : " + str(r["result"]["isya"])
							kalera.sendReplyMessage(msg.id, to, str(ret))
						elif penah.startswith("quotes"):
							r = json.loads(requests.get(f"https://ibalapi.herokuapp.com/api/quotes").text)
							ret = "「Random Quotes」\n"
							ret += "\n• Author: " + str(r["result"]["author"])
							ret += "\n• Quote:  " + str(r["result"]["quote"])
							ret += "\n• Category:  " + str(r["result"]["category"])
							kalera.sendReplyMessage(msg.id, to, str(ret))
						elif penah.startswith("getpicture "):
							if 'MENTION' in msg.contentMetadata.keys()!= None:
								names = re.findall(r'@(\w+)', text)
								mention = ast.literal_eval(msg.contentMetadata['MENTION'])
								mentionees = mention['MENTIONEES']
								lists = []
								for mention in mentionees:
									if mention["M"] not in lists:
										lists.append(mention["M"])
								for ls in lists:
									kalera.sendImageWithURL(to,f"https://obs.line-scdn.net/{devi.getContact(ls).pictureStatus}")
									kalera.sendReplyMessage(msg.id,to,f"https://obs.line-scdn.net/{devi.getContact(ls).pictureStatus}")
						elif penah.startswith("getname "):
							if 'MENTION' in msg.contentMetadata.keys()!= None:
								names = re.findall(r'@(\w+)', text)
								mention = ast.literal_eval(msg.contentMetadata['MENTION'])
								mentionees = mention['MENTIONEES']
								lists = []
								for mention in mentionees:
									if mention["M"] not in lists:
										lists.append(mention["M"])
								for ls in lists:
									kalera.sendReplyMessage(msg.id,to,"⌬ Name \n" + str(devi.getContact(ls).displayName))
						elif penah.startswith("getcontact "):
							if 'MENTION' in msg.contentMetadata.keys()!= None:
								names = re.findall(r'@(\w+)', text)
								mention = ast.literal_eval(msg.contentMetadata['MENTION'])
								mentionees = mention['MENTIONEES']
								lists = []
								for mention in mentionees:
									if mention["M"] not in lists:
										lists.append(mention["M"])
								for ls in lists:
									contact = devi.getContact(ls)
									mi_d = contact.mid
									kalera.sendContact(to, mi_d)
						elif penah == "tagall":
							group = kalera.getGroup(to)
							member = [a.mid for a in group.members]
							member.remove(kalera.profile.mid)
							kalera.datamention(to,"Mention Members",member)
						elif penah.startswith("getbio "):
							if 'MENTION' in msg.contentMetadata.keys()!= None:
								names = re.findall(r'@(\w+)', text)
								mention = ast.literal_eval(msg.contentMetadata['MENTION'])
								mentionees = mention['MENTIONEES']
								lists = []
								for mention in mentionees:
									if mention["M"] not in lists:
										lists.append(mention["M"])
								for ls in lists:
									kalera.sendReplyMessage(msg.id,to,"Status Message\n" + str(devi.getContact(ls).statusMessage))
						elif penah.startswith("getcover "):
							if 'MENTION' in msg.contentMetadata.keys()!= None:
								names = re.findall(r'@(\w+)', text)
								mention = ast.literal_eval(msg.contentMetadata['MENTION'])
								mentionees = mention['MENTIONEES']
								lists = []
								for mention in mentionees:
									if mention["M"] not in lists:
										lists.append(mention["M"])
								for ls in lists:
									image = kalera.getProfileCoverURL(ls)
									path = str(image)
									kalera.sendReplyMessage(msg.id,to,path)
						elif penah.startswith("kick "):
							targets = []
							key = eval(msg.contentMetadata["MENTION"])
							key["MENTIONEES"] [0] ["M"]
							for x in key["MENTIONEES"]:
								targets.append(x["M"])
							for target in targets:
								try:
									kalera.kickoutFromGroup(to, [target])
								except Exception as e:
									kalera.sendReplyMessage(reply, receiver, str(e))
						elif penah.startswith("bcast "):
							sep = text.split(" ")
							pesan = text.replace(sep[0] + " ","")
							saya = kalera.getGroupIdsJoined()
							for group in saya:
								kalera.sendMessage(group,"" + str(pesan))
								time.sleep(3)
								kalera.sendMessage(msg.id, to, "Success Broadcast")
						elif penah.startswith('chat '):
							try:
								if 'MENTION' in msg.contentMetadata.keys()!=None:
									key = eval(msg.contentMetadata["MENTION"])
									key1 = key["MENTIONEES"][0]["M"]
									nama = kalera.getContact(key1).displayName
									anu = kalera.getContact(key1)
									if len(penah.split(" ")) >= 2:
										mid  = "{}".format(key1)
										text = "{}".format(str(ibal.replace(ibal.split(" ")[0]+" ","")))
										icon = "http://dl.profile.line.naver.jp/{}".format(anu.pictureStatus)
										name = "{}".format(anu.displayName)
										b = [sendMessageCustom(key1, text, icon, name)];kalera.sendMention(to, '「 Personal Chat 」\n@! Please Cek My Pc','',[key1])
							except Exception as e:
								kalera.sendReplyMessage(msg.id, to, f"⌬ Notification Error ⌬\n⌬ {e}")
#============================================
#End
		if op.type == 55:
			try:
				if op.param1 in read['readPoint']:
					if op.param2 in read['readMember'][op.param1]:
						pass
					else:
						read['readMember'][op.param1] += op.param2
					read['ROM'][op.param1][op.param2] = op.param2
				if cctv['cyduk'][op.param1]==True:
					if op.param1 in cctv['point']:
						Name = kalera.getContact(op.param2).displayName
						if Name in cctv['sidermem'][op.param1]:
							pass
						else:
							cctv['sidermem'][op.param1] += "~ " + Name
							siderMembers(op.param1, [op.param2])
							contact = kalera.getContact(op.param2)
					backupData()
				else:
					pass
			except:
				pass
	except Exception as error:
		error = traceback.format_exc()
def run_bot():
	while True:
		try:
			ops = kalera_poll.singleTrace(count=50)
			if ops != None:
				for op in ops:
					loop.run_until_complete(ibal_kalera(op))
					kalera_poll.setRevision(op.revision)
		except TalkException as error:
			traceback.print_tb(error.__traceback__)
if __name__ == "__main__":
	run_bot()
